from langbot_plugin.api.definition.plugin import BasePlugin

class Plugin(BasePlugin):
    async def initialize(self):
        await super().initialize()

    async def dispose(self):
        from components.event_listener.default import DefaultEventListener
        listener = DefaultEventListener.get_active()
        if listener:
            await listener.dispose()
        await super().dispose()
